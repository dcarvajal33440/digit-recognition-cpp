// util.hpp - wall-clock timer, peak-memory readout, small RNG helpers.
#pragma once

#include <sys/resource.h>

#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <random>
#include <string>

namespace nn {

struct Timer {
    using clk = std::chrono::steady_clock;
    clk::time_point t0 = clk::now();
    void reset() { t0 = clk::now(); }
    double sec() const { return std::chrono::duration<double>(clk::now() - t0).count(); }
};

// Peak resident set size of this process in MiB (high-water mark, from the kernel).
inline double peak_rss_mib() {
    rusage ru{};
    getrusage(RUSAGE_SELF, &ru);
    return double(ru.ru_maxrss) / 1024.0;  // Linux reports KiB
}

// Current resident set size in MiB (from /proc/self/statm).
inline double current_rss_mib() {
    FILE* f = std::fopen("/proc/self/statm", "r");
    if (!f) return 0;
    long total = 0, resident = 0;
    if (std::fscanf(f, "%ld %ld", &total, &resident) != 2) resident = 0;
    std::fclose(f);
    return double(resident) * 4096.0 / (1024.0 * 1024.0);
}

}  // namespace nn
