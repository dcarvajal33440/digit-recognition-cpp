// test_gemm.cpp - every kernel x every product variant must agree with a plain
// double-precision reference, on shapes chosen to hit the ragged-edge code.
#include <cmath>
#include <cstdio>
#include <random>
#include <vector>

#include "gemm.hpp"

using namespace nn;

template <class T>
static double check(Kernel kern, int variant, size_t M, size_t N, size_t K, bool acc, std::mt19937_64& rng) {
    std::uniform_real_distribution<double> U(-1.0, 1.0);
    // Operand shapes depend on the variant: 0 = nn, 1 = tn, 2 = nt
    Matrix<T> A(variant == 1 ? K : M, variant == 1 ? M : K);
    Matrix<T> B(variant == 2 ? N : K, variant == 2 ? K : N);
    for (size_t i = 0; i < A.size(); ++i) A.data()[i] = T(U(rng));
    for (size_t i = 0; i < B.size(); ++i) B.data()[i] = T(U(rng));

    Matrix<T> C(M, N);
    std::vector<double> ref(M * N, 0.0);
    if (acc)
        for (size_t i = 0; i < M * N; ++i) { C.data()[i] = T(U(rng)); ref[i] = double(C.data()[i]); }

    for (size_t i = 0; i < M; ++i)
        for (size_t j = 0; j < N; ++j) {
            double s = 0;
            for (size_t k = 0; k < K; ++k) {
                const double a = variant == 1 ? double(A(k, i)) : double(A(i, k));
                const double b = variant == 2 ? double(B(j, k)) : double(B(k, j));
                s += a * b;
            }
            ref[i * N + j] += s;
        }

    g_kernel = kern;
    if (variant == 0) gemm_nn(A, B, C, acc);
    else if (variant == 1) gemm_tn(A, B, C, acc);
    else gemm_nt(A, B, C, acc);

    double worst = 0;
    for (size_t i = 0; i < M * N; ++i) worst = std::max(worst, std::fabs(double(C.data()[i]) - ref[i]));
    return worst;
}

int main() {
    std::mt19937_64 rng(12345);
    struct Shape { size_t M, N, K; };
    const Shape shapes[] = {
        {1, 1, 1},     {5, 7, 3},      {4, 32, 8},      {37, 53, 41},   {64, 128, 784},
        {784, 128, 64}, {64, 784, 128}, {64, 10, 128},  {129, 17, 300}, {33, 65, 257},
        {100, 100, 100}, {2, 300, 5},
        // full-height tiles with ragged width -> padded-tile path (M multiple of 8 and of 6)
        {48, 10, 20},  {64, 33, 300}, {24, 1, 9},   {64, 10, 128}, {48, 47, 513}, {96, 16, 17}, {120, 31, 256},
    };
    const Kernel kernels[] = {Kernel::Naive, Kernel::Reordered, Kernel::Blocked, Kernel::Tiled};
    const char* vname[] = {"nn", "tn", "nt"};

    int failures = 0, total = 0;
    double worst_f = 0, worst_d = 0;
    for (Kernel k : kernels)
        for (int v = 0; v < 3; ++v)
            for (const Shape& s : shapes)
                for (bool acc : {false, true}) {
                    const double ef = check<float>(k, v, s.M, s.N, s.K, acc, rng);
                    const double ed = check<double>(k, v, s.M, s.N, s.K, acc, rng);
                    worst_f = std::max(worst_f, ef);
                    worst_d = std::max(worst_d, ed);
                    // error bound grows ~ sqrt(K) * eps
                    const double tol_f = 1e-4 * std::sqrt(double(s.K)) / 10, tol_d = 1e-11;
                    ++total;
                    if (ef > tol_f || ed > tol_d) {
                        ++failures;
                        std::printf("FAIL %-9s %s  %zux%zux%zu acc=%d  float err %.3g (tol %.3g)  double err %.3g\n",
                                    kernel_name(k), vname[v], s.M, s.N, s.K, int(acc), ef, tol_f, ed);
                    }
                }
    std::printf("gemm tests: %d cases, %d failures | worst abs error: float %.3g, double %.3g\n", total, failures,
                worst_f, worst_d);
    return failures ? 1 : 0;
}
