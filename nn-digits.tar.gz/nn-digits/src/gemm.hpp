// gemm.hpp - dense matrix multiplication, from scratch, at four optimisation levels.
//
// Backprop needs three products (A, B are stored row-major):
//     gemm_nn : C = A   * B      forward pass          Z  = X * W
//     gemm_tn : C = A^T * B      weight gradient       dW = Input^T * dZ
//     gemm_nt : C = A   * B^T    input gradient        dA = dZ * W^T
//
// The kernel is chosen at run time (g_kernel) so every level can be benchmarked
// inside one binary:
//     Naive      textbook i-j-k triple loop
//     Reordered  i-k-j order: the inner loop walks B and C with stride 1
//     Blocked    + cache tiling (single thread)
//     Tiled      + register-blocked MRxNR SIMD micro-kernel (accumulators in vector
//                registers), padded edge tiles, OpenMP over tiles
#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdlib>
#include <cstring>

#include "tensor.hpp"

namespace nn {

enum class Kernel { Naive, Reordered, Blocked, Tiled };
inline Kernel g_kernel = Kernel::Tiled;

inline const char* kernel_name(Kernel k) {
    switch (k) {
        case Kernel::Naive: return "naive";
        case Kernel::Reordered: return "reordered";
        case Kernel::Blocked: return "blocked";
        case Kernel::Tiled: return "tiled";
    }
    return "?";
}
inline bool parse_kernel(const char* s, Kernel& out) {
    for (Kernel k : {Kernel::Naive, Kernel::Reordered, Kernel::Blocked, Kernel::Tiled})
        if (std::strcmp(s, kernel_name(k)) == 0) { out = k; return true; }
    return false;
}

namespace detail {

// ---- 0. naive ---------------------------------------------------------------
template <class T>
void naive_nn(const T* A, const T* B, T* C, size_t M, size_t N, size_t K, bool acc) {
    for (size_t i = 0; i < M; ++i)
        for (size_t j = 0; j < N; ++j) {
            T s = acc ? C[i * N + j] : T(0);
            for (size_t k = 0; k < K; ++k) s += A[i * K + k] * B[k * N + j];  // B walked with stride N
            C[i * N + j] = s;
        }
}
template <class T>  // A is K x M
void naive_tn(const T* A, const T* B, T* C, size_t M, size_t N, size_t K, bool acc) {
    for (size_t i = 0; i < M; ++i)
        for (size_t j = 0; j < N; ++j) {
            T s = acc ? C[i * N + j] : T(0);
            for (size_t k = 0; k < K; ++k) s += A[k * M + i] * B[k * N + j];
            C[i * N + j] = s;
        }
}
template <class T>  // B is N x K
void naive_nt(const T* A, const T* B, T* C, size_t M, size_t N, size_t K, bool acc) {
    for (size_t i = 0; i < M; ++i)
        for (size_t j = 0; j < N; ++j) {
            T s = acc ? C[i * N + j] : T(0);
            for (size_t k = 0; k < K; ++k) s += A[i * K + k] * B[j * K + k];
            C[i * N + j] = s;
        }
}

// ---- 1. loop reordering -----------------------------------------------------
template <class T>
void reordered_nn(const T* A, const T* B, T* C, size_t M, size_t N, size_t K, bool acc) {
    if (!acc) std::memset(C, 0, M * N * sizeof(T));
    for (size_t i = 0; i < M; ++i)
        for (size_t k = 0; k < K; ++k) {
            const T a = A[i * K + k];
            T* c = C + i * N;
            const T* b = B + k * N;
#pragma omp simd
            for (size_t j = 0; j < N; ++j) c[j] += a * b[j];
        }
}

// ---- 2. cache blocking ------------------------------------------------------
template <class T>
void blocked_nn(const T* A, const T* B, T* C, size_t M, size_t N, size_t K, bool acc) {
    constexpr size_t MC = 64, NC = 256, KC = 256;
    if (!acc) std::memset(C, 0, M * N * sizeof(T));
    for (size_t jc = 0; jc < N; jc += NC) {
        const size_t nc = std::min(NC, N - jc);
        for (size_t kc0 = 0; kc0 < K; kc0 += KC) {
            const size_t kc = std::min(KC, K - kc0);
            for (size_t ic = 0; ic < M; ic += MC) {
                const size_t mc = std::min(MC, M - ic);
                for (size_t i = 0; i < mc; ++i)
                    for (size_t k = 0; k < kc; ++k) {
                        const T a = A[(ic + i) * K + kc0 + k];
                        T* c = C + (ic + i) * N + jc;
                        const T* b = B + (kc0 + k) * N + jc;
#pragma omp simd
                        for (size_t j = 0; j < nc; ++j) c[j] += a * b[j];
                    }
            }
        }
    }
}

// ---- 3. register tiling + SIMD + threads -------------------------------------
// A MR x NR block of C lives in vector registers for the whole k loop, so each
// FMA needs no load/store of C. B is read as contiguous NR-wide row segments,
// A as one broadcast scalar per row.
//
// The accumulators are declared as SIMD vector types (GCC vector extensions).
// An earlier version used a plain T acc[MR][NR] array: GCC kept it in memory and
// reloaded/stored it around every FMA (visible in the assembly as (%rsp) operands),
// which made it ~7x SLOWER than the simple loop-reordered kernel. Real vector
// variables are what let the register allocator keep the whole tile in registers.
#if defined(__AVX512F__)
constexpr size_t kVecBytes = 64;
#else
constexpr size_t kVecBytes = 32;
#endif
template <class T>
struct Vec {
    static constexpr int L = int(kVecBytes / sizeof(T));  // lanes
    typedef T v __attribute__((vector_size(kVecBytes)));
    typedef T vu __attribute__((vector_size(kVecBytes), aligned(sizeof(T)), may_alias));  // unaligned access
};
constexpr int kNV = 2;                                   // vectors per tile row
constexpr int mr_of(size_t vb) { return vb == 64 ? 8 : 6; }  // 16 (or 12) accumulators + operands fit the register file
constexpr int kMR = mr_of(kVecBytes);

template <class T, int MR, int NV>
inline void micro(const T* __restrict A, size_t lda, const T* __restrict B, size_t ldb,
                  T* __restrict C, size_t ldc, size_t kc) {
    using V = typename Vec<T>::v;
    using VU = typename Vec<T>::vu;
    constexpr int L = Vec<T>::L;
    V acc[MR][NV];
#pragma GCC unroll 16
    for (int i = 0; i < MR; ++i)
#pragma GCC unroll 4
        for (int j = 0; j < NV; ++j) acc[i][j] = *reinterpret_cast<const VU*>(C + i * ldc + j * L);
    for (size_t k = 0; k < kc; ++k) {
        const T* b = B + k * ldb;
        V bv[NV];
#pragma GCC unroll 4
        for (int j = 0; j < NV; ++j) bv[j] = *reinterpret_cast<const VU*>(b + j * L);
#pragma GCC unroll 16
        for (int i = 0; i < MR; ++i) {
            const T a = A[i * lda + k];
#pragma GCC unroll 4
            for (int j = 0; j < NV; ++j) acc[i][j] += a * bv[j];  // scalar a is broadcast
        }
    }
#pragma GCC unroll 16
    for (int i = 0; i < MR; ++i)
#pragma GCC unroll 4
        for (int j = 0; j < NV; ++j) *reinterpret_cast<VU*>(C + i * ldc + j * L) = acc[i][j];
}

constexpr size_t kKC = 256;  // k-panel depth (also sizes the padding buffer below)

// A full-height tile (MR rows) that is narrower than the micro-tile: copy the B panel
// and the C tile into zero-padded local buffers, run the fast micro-kernel, copy the
// nr valid columns back. Keeps the 10-wide softmax layer off the scalar path.
template <class T, int NV>
inline void padded_tile(const T* A, size_t lda, const T* B, size_t ldb, T* C, size_t ldc, size_t nr, size_t kc) {
    constexpr int W = Vec<T>::L * NV;
    alignas(64) T bp[kKC * W];
    alignas(64) T cp[kMR * W];
    for (size_t k = 0; k < kc; ++k) {
        for (size_t j = 0; j < nr; ++j) bp[k * W + j] = B[k * ldb + j];
        for (size_t j = nr; j < size_t(W); ++j) bp[k * W + j] = T(0);
    }
    for (int i = 0; i < kMR; ++i) {
        for (size_t j = 0; j < nr; ++j) cp[i * W + j] = C[i * ldc + j];
        for (size_t j = nr; j < size_t(W); ++j) cp[i * W + j] = T(0);
    }
    micro<T, kMR, NV>(A, lda, bp, W, cp, W, kc);
    for (int i = 0; i < kMR; ++i)
        for (size_t j = 0; j < nr; ++j) C[i * ldc + j] = cp[i * W + j];
}

// Ragged edges (rows/cols that do not fill a whole micro-tile).
template <class T>
inline void edge(const T* A, size_t lda, const T* B, size_t ldb, T* C, size_t ldc,
                 size_t mr, size_t nr, size_t kc) {
    for (size_t i = 0; i < mr; ++i)
        for (size_t k = 0; k < kc; ++k) {
            const T a = A[i * lda + k];
            const T* b = B + k * ldb;
            T* c = C + i * ldc;
#pragma omp simd
            for (size_t j = 0; j < nr; ++j) c[j] += a * b[j];
        }
}

template <class T>
void tiled_nn(const T* A, const T* B, T* C, size_t M, size_t N, size_t K, bool acc) {
    constexpr int MR = kMR;
    constexpr int NR = Vec<T>::L * kNV;  // tile width in elements (32 floats with AVX-512)
    constexpr size_t MC = (32 / MR) * MR, NC = 2 * NR, KC = kKC;
    if (!acc) std::memset(C, 0, M * N * sizeof(T));
    const long nIC = long((M + MC - 1) / MC), nJC = long((N + NC - 1) / NC);
    [[maybe_unused]] const bool par = M * N * K >= (size_t(1) << 18);  // do not pay thread start-up on tiny products
#pragma omp parallel for collapse(2) schedule(static) if (par)
    for (long ti = 0; ti < nIC; ++ti)
        for (long tj = 0; tj < nJC; ++tj) {
            const size_t ic = size_t(ti) * MC, jc = size_t(tj) * NC;
            const size_t mc = std::min(MC, M - ic), nc = std::min(NC, N - jc);
            for (size_t kc0 = 0; kc0 < K; kc0 += KC) {
                const size_t kc = std::min(KC, K - kc0);
                for (size_t jr = 0; jr < nc; jr += NR) {
                    const size_t nr = std::min<size_t>(NR, nc - jr);
                    for (size_t ir = 0; ir < mc; ir += MR) {
                        const size_t mr = std::min<size_t>(MR, mc - ir);
                        const T* a = A + (ic + ir) * K + kc0;
                        const T* b = B + kc0 * N + jc + jr;
                        T* c = C + (ic + ir) * N + jc + jr;
                        if (mr == size_t(MR) && nr == size_t(NR)) micro<T, MR, kNV>(a, K, b, N, c, N, kc);
                        else if (mr == size_t(MR) && nr <= size_t(Vec<T>::L)) padded_tile<T, 1>(a, K, b, N, c, N, nr, kc);
                        else if (mr == size_t(MR)) padded_tile<T, kNV>(a, K, b, N, c, N, nr, kc);
                        else edge(a, K, b, N, c, N, mr, nr, kc);
                    }
                }
            }
        }
}

// ---- helpers ----------------------------------------------------------------
// Grow-only scratch so repeated transposes do not hit malloc/mmap + page faults.
template <class T>
T* scratch(int slot, size_t n) {
    struct Buf { T* p = nullptr; size_t cap = 0; ~Buf() { std::free(p); } };
    static thread_local Buf bufs[2];
    Buf& b = bufs[slot];
    if (n > b.cap) {
        std::free(b.p);
        b.cap = (n * sizeof(T) + 63) / 64 * 64 / sizeof(T);
        b.p = static_cast<T*>(std::aligned_alloc(64, b.cap * sizeof(T)));
        if (!b.p) throw std::bad_alloc();
    }
    return b.p;
}

template <class T>  // dst (C x R) = src (R x C)^T
void transpose_raw(const T* src, size_t R, size_t C, T* dst) {
    constexpr size_t BS = 32;
    for (size_t i0 = 0; i0 < R; i0 += BS)
        for (size_t j0 = 0; j0 < C; j0 += BS) {
            const size_t i1 = std::min(i0 + BS, R), j1 = std::min(j0 + BS, C);
            for (size_t i = i0; i < i1; ++i)
                for (size_t j = j0; j < j1; ++j) dst[j * R + i] = src[i * C + j];
        }
}

template <class T>
void dispatch_nn(const T* A, const T* B, T* C, size_t M, size_t N, size_t K, bool acc) {
    switch (g_kernel) {
        case Kernel::Naive: naive_nn(A, B, C, M, N, K, acc); break;
        case Kernel::Reordered: reordered_nn(A, B, C, M, N, K, acc); break;
        case Kernel::Blocked: blocked_nn(A, B, C, M, N, K, acc); break;
        case Kernel::Tiled: tiled_nn(A, B, C, M, N, K, acc); break;
    }
}

}  // namespace detail

// C = A * B          A: MxK, B: KxN
template <class T>
void gemm_nn(const Matrix<T>& A, const Matrix<T>& B, Matrix<T>& C, bool acc = false) {
    const size_t M = A.rows(), K = A.cols(), N = B.cols();
    if (B.rows() != K) std::abort();
    C.resize(M, N);
    detail::dispatch_nn(A.data(), B.data(), C.data(), M, N, K, acc);
}

// C = A^T * B        A: KxM, B: KxN
template <class T>
void gemm_tn(const Matrix<T>& A, const Matrix<T>& B, Matrix<T>& C, bool acc = false) {
    const size_t K = A.rows(), M = A.cols(), N = B.cols();
    if (B.rows() != K) std::abort();
    C.resize(M, N);
    if (g_kernel == Kernel::Naive) {
        detail::naive_tn(A.data(), B.data(), C.data(), M, N, K, acc);
    } else {  // transpose A once (O(MK)) so the fast nn kernel can be reused
        T* At = detail::scratch<T>(0, M * K);
        detail::transpose_raw(A.data(), K, M, At);
        detail::dispatch_nn(At, B.data(), C.data(), M, N, K, acc);
    }
}

// C = A * B^T        A: MxK, B: NxK
template <class T>
void gemm_nt(const Matrix<T>& A, const Matrix<T>& B, Matrix<T>& C, bool acc = false) {
    const size_t M = A.rows(), K = A.cols(), N = B.rows();
    if (B.cols() != K) std::abort();
    C.resize(M, N);
    if (g_kernel == Kernel::Naive) {
        detail::naive_nt(A.data(), B.data(), C.data(), M, N, K, acc);
    } else {
        T* Bt = detail::scratch<T>(1, K * N);
        detail::transpose_raw(B.data(), N, K, Bt);
        detail::dispatch_nn(A.data(), Bt, C.data(), M, N, K, acc);
    }
}

}  // namespace nn
