// neuron.cpp - Stage 1: a single sigmoid neuron.
//
//     z = w . x + b        p = sigmoid(z)        L = -[ y log p + (1-y) log(1-p) ]
//
// Closed-form gradient (the whole of backprop for one neuron):
//     dL/dz = p - y        dL/dw = (p - y) x        dL/db = p - y
//
// Task: "is this image the digit D?"  (binary, one-vs-rest).  With --all it trains
// ten such neurons and classifies by taking the most confident one - the bridge to
// the multi-class network in train_mlp.cpp.
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <numeric>
#include <random>
#include <string>
#include <vector>

#include "activations.hpp"
#include "mnist.hpp"
#include "util.hpp"

using namespace nn;

template <class T>
struct Neuron {
    std::vector<T> w;
    T b = 0;
    explicit Neuron(size_t d) : w(d, T(0)) {}
    T logit(const T* x) const {
        T s = b;
        for (size_t j = 0; j < w.size(); ++j) s += w[j] * x[j];
        return s;
    }
};

// Mean binary cross-entropy over a batch and its gradient.
// Uses  L = softplus(z) - y z  with softplus(z) = max(z,0) + log1p(exp(-|z|)),
// which is exact and never overflows or takes log(0).
template <class T>
T loss_and_grad(const Neuron<T>& n, const T* X, const T* y, size_t B, std::vector<T>& dw, T& db) {
    const size_t d = n.w.size();
    std::fill(dw.begin(), dw.end(), T(0));
    db = 0;
    T loss = 0;
    for (size_t i = 0; i < B; ++i) {
        const T* x = X + i * d;
        const T z = n.logit(x);
        loss += std::max(z, T(0)) + std::log1p(std::exp(-std::fabs(z))) - y[i] * z;
        const T dz = sigmoid(z) - y[i];
        for (size_t j = 0; j < d; ++j) dw[j] += dz * x[j];
        db += dz;
    }
    const T inv = T(1) / T(B);
    for (size_t j = 0; j < d; ++j) dw[j] *= inv;
    db *= inv;
    return loss * inv;
}

// Compare the analytic gradient with central finite differences, in double precision.
static bool gradient_check() {
    std::mt19937_64 rng(7);
    std::normal_distribution<double> N(0, 1);
    const size_t B = 16, d = 12;
    std::vector<double> X(B * d), y(B);
    for (auto& v : X) v = N(rng);
    for (auto& v : y) v = (rng() & 1) ? 1.0 : 0.0;
    Neuron<double> n(d);
    for (auto& v : n.w) v = N(rng);
    n.b = N(rng);

    std::vector<double> dw(d), tmp(d);
    double db = 0, dummy = 0;
    loss_and_grad(n, X.data(), y.data(), B, dw, db);

    const double eps = 1e-6;
    double worst = 0;
    for (size_t k = 0; k <= d; ++k) {
        double& p = (k < d) ? n.w[k] : n.b;
        const double saved = p;
        p = saved + eps;
        const double lp = loss_and_grad(n, X.data(), y.data(), B, tmp, dummy);
        p = saved - eps;
        const double lm = loss_and_grad(n, X.data(), y.data(), B, tmp, dummy);
        p = saved;
        const double num = (lp - lm) / (2 * eps), ana = (k < d) ? dw[k] : db;
        worst = std::max(worst, std::fabs(num - ana) / std::max(1e-8, std::fabs(num) + std::fabs(ana)));
    }
    std::printf("gradient check (double, central differences): max relative error = %.2e  %s\n", worst,
                worst < 1e-6 ? "PASS" : "FAIL");
    return worst < 1e-6;
}

struct Metrics { double acc, prec, rec, f1; size_t tp, fp, fn, tn; };

static Metrics evaluate(const Neuron<float>& n, const Dataset& d, int digit) {
    Metrics m{};
    for (size_t i = 0; i < d.n; ++i) {
        float z = n.b;
        const uint8_t* px = d.pixels.data() + i * d.dim;
        for (size_t j = 0; j < d.dim; ++j) z += n.w[j] * (px[j] * (1.0f / 255.0f));
        const bool pred = z > 0, truth = d.labels[i] == digit;  // sigmoid(z) > 0.5  <=>  z > 0
        (pred ? (truth ? m.tp : m.fp) : (truth ? m.fn : m.tn))++;
    }
    m.acc = double(m.tp + m.tn) / d.n;
    m.prec = m.tp + m.fp ? double(m.tp) / (m.tp + m.fp) : 0;
    m.rec = m.tp + m.fn ? double(m.tp) / (m.tp + m.fn) : 0;
    m.f1 = m.prec + m.rec > 0 ? 2 * m.prec * m.rec / (m.prec + m.rec) : 0;
    return m;
}

static Neuron<float> train_neuron(const Dataset& tr, int digit, int epochs, float lr, size_t batch, uint64_t seed,
                                  bool verbose) {
    std::mt19937_64 rng(seed);
    std::normal_distribution<float> N(0.f, 0.01f);
    Neuron<float> n(tr.dim);
    for (auto& v : n.w) v = N(rng);

    std::vector<size_t> order(tr.n);
    std::iota(order.begin(), order.end(), 0);
    Matrix<float> X;
    std::vector<uint8_t> yl;
    std::vector<float> y(batch), dw(tr.dim);

    for (int e = 1; e <= epochs; ++e) {
        std::shuffle(order.begin(), order.end(), rng);
        double sum = 0;
        size_t nb = 0;
        for (size_t s = 0; s + batch <= tr.n; s += batch, ++nb) {
            tr.fill_batch(order.data() + s, batch, X, yl);
            for (size_t i = 0; i < batch; ++i) y[i] = yl[i] == digit ? 1.f : 0.f;
            float db;
            sum += loss_and_grad(n, X.data(), y.data(), batch, dw, db);
            for (size_t j = 0; j < tr.dim; ++j) n.w[j] -= lr * dw[j];  // gradient descent step
            n.b -= lr * db;
        }
        if (verbose) std::printf("  epoch %d  mean loss %.4f\n", e, sum / nb);
    }
    return n;
}

int main(int argc, char** argv) {
    std::string dir = "data";
    int digit = 0, epochs = 5;
    float lr = 0.1f;
    size_t batch = 64;
    bool all = false;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        auto next = [&]() { return std::string(argv[++i]); };
        if (a == "--data") dir = next();
        else if (a == "--digit") digit = std::stoi(next());
        else if (a == "--epochs") epochs = std::stoi(next());
        else if (a == "--lr") lr = std::stof(next());
        else if (a == "--batch") batch = std::stoul(next());
        else if (a == "--all") all = true;
        else { std::fprintf(stderr, "unknown flag %s\n", a.c_str()); return 2; }
    }

    if (!gradient_check()) return 1;

    Dataset tr = load_mnist(dir + "/train-images-idx3-ubyte", dir + "/train-labels-idx1-ubyte");
    Dataset te = load_mnist(dir + "/t10k-images-idx3-ubyte", dir + "/t10k-labels-idx1-ubyte");
    std::printf("loaded MNIST: %zu train, %zu test, %zu pixels each\n", tr.n, te.n, tr.dim);

    if (!all) {
        std::printf("\nsingle neuron: is it a '%d'?  (epochs=%d lr=%g batch=%zu)\n", digit, epochs, lr, batch);
        Timer t;
        Neuron<float> n = train_neuron(tr, digit, epochs, lr, batch, 1, true);
        const double secs = t.sec();
        const Metrics a = evaluate(n, tr, digit), b = evaluate(n, te, digit);
        size_t pos = 0;
        for (size_t i = 0; i < te.n; ++i) pos += te.labels[i] == digit;
        const double base = 1.0 - double(pos) / te.n;
        std::printf("training time %.2fs\n", secs);
        std::printf("train: acc %.4f | test: acc %.4f  precision %.4f  recall %.4f  F1 %.4f\n", a.acc, b.acc, b.prec, b.rec, b.f1);
        std::printf("test confusion: TP=%zu FP=%zu FN=%zu TN=%zu   (always-say-'no' baseline accuracy: %.4f)\n", b.tp, b.fp, b.fn, b.tn, base);
        return 0;
    }

    // One neuron per digit; classify by the largest logit.
    std::printf("\nten one-vs-rest neurons (epochs=%d lr=%g batch=%zu)\n", epochs, lr, batch);
    std::vector<Neuron<float>> ns;
    Timer t;
    for (int dgt = 0; dgt < 10; ++dgt) {
        ns.push_back(train_neuron(tr, dgt, epochs, lr, batch, 100 + dgt, false));
        const Metrics m = evaluate(ns.back(), te, dgt);
        std::printf("  digit %d: binary test acc %.4f  precision %.4f  recall %.4f\n", dgt, m.acc, m.prec, m.rec);
    }
    const double secs = t.sec();
    size_t correct = 0;
    for (size_t i = 0; i < te.n; ++i) {
        const uint8_t* px = te.pixels.data() + i * te.dim;
        int best = 0;
        float bz = -1e30f;
        for (int dgt = 0; dgt < 10; ++dgt) {
            float z = ns[dgt].b;
            for (size_t j = 0; j < te.dim; ++j) z += ns[dgt].w[j] * (px[j] * (1.0f / 255.0f));
            if (z > bz) { bz = z; best = dgt; }
        }
        correct += best == te.labels[i];
    }
    std::printf("training time %.2fs | 10-way accuracy of the ten neurons on unseen test images: %.2f%% (%zu/%zu)\n", secs,
                100.0 * correct / te.n, correct, te.n);
    return 0;
}
