// test_grad.cpp - numerical gradient check of the full MLP backprop (double precision).
// For every parameter p:  (L(p+e) - L(p-e)) / 2e  must match the analytic dL/dp.
#include <cmath>
#include <cstdio>
#include <random>

#include "mlp.hpp"

using namespace nn;

static double run(Act act, const char* name, Kernel kern) {
    g_kernel = kern;
    const size_t B = 7;
    const std::vector<size_t> sizes = {9, 6, 5, 4};
    MLP<double> net(sizes, act, 99);
    std::mt19937_64 rng(3);
    std::normal_distribution<double> N(0, 1);
    Matrix<double> X(B, sizes[0]);
    for (size_t i = 0; i < X.size(); ++i) X.data()[i] = N(rng);
    std::vector<uint8_t> y(B);
    for (auto& v : y) v = uint8_t(rng() % sizes.back());
    // non-zero biases so their gradients are exercised too
    for (auto& ly : net.layers())
        for (size_t i = 0; i < ly.b.size(); ++i) ly.b.data()[i] = 0.1 * N(rng);

    net.forward(X);
    net.backward(X, y);

    auto L = [&]() { net.forward(X); return net.loss(y); };
    const double eps = 1e-6;
    double worst = 0;
    size_t checked = 0;
    for (auto& ly : net.layers()) {
        for (Matrix<double>* pair : {&ly.W, &ly.b}) {
            const Matrix<double>& G = (pair == &ly.W) ? ly.dW : ly.db;
            for (size_t i = 0; i < pair->size(); ++i) {
                double& p = pair->data()[i];
                const double saved = p;
                p = saved + eps; const double lp = L();
                p = saved - eps; const double lm = L();
                p = saved;
                const double num = (lp - lm) / (2 * eps), ana = G.data()[i];
                worst = std::max(worst, std::fabs(num - ana) / std::max(1e-7, std::fabs(num) + std::fabs(ana)));
                ++checked;
            }
        }
    }
    std::printf("%-8s %-9s  %zu parameters checked, max relative error %.2e  %s\n", name, kernel_name(kern), checked, worst,
                worst < 1e-5 ? "PASS" : "FAIL");
    return worst;
}

int main() {
    double w = 0;
    for (Kernel k : {Kernel::Naive, Kernel::Tiled}) {
        w = std::max(w, run(Act::ReLU, "ReLU", k));
        w = std::max(w, run(Act::Sigmoid, "sigmoid", k));
        w = std::max(w, run(Act::Tanh, "tanh", k));
    }
    return w < 1e-5 ? 0 : 1;
}
