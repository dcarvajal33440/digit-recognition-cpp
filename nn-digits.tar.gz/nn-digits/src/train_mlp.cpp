// train_mlp.cpp - Stage 2: train a multilayer perceptron on MNIST and measure it.
//
//   ./train_mlp --hidden 128 --epochs 10 --lr 0.1 --batch 64
//
// 60k training images are split 55k train / 5k validation. The validation set is
// what you tune against; the 10k test images are touched only once, at the end.
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif

#include "mlp.hpp"
#include "mnist.hpp"

using namespace nn;

struct Options {
    std::string data = "data";
    std::vector<size_t> hidden = {128};
    Act act = Act::ReLU;
    int epochs = 10;
    double lr = 0.1, mu = 0.9, lr_decay = 1.0;
    size_t batch = 64, val = 5000;
    uint64_t seed = 1;
    bool use_double = false, preload = false, quiet = false, csv = false;
    Kernel kernel = Kernel::Tiled;
};

static std::vector<size_t> parse_list(const std::string& s) {
    std::vector<size_t> v;
    std::stringstream ss(s);
    std::string tok;
    while (std::getline(ss, tok, ',')) v.push_back(std::stoul(tok));
    return v;
}

struct EvalResult { double acc, loss; };

// Accuracy + mean loss on rows idx[0..n) of ds, in forward-only batches.
template <class T>
static EvalResult evaluate(MLP<T>& net, const Dataset& ds, const std::vector<size_t>& idx, std::vector<std::vector<int>>* confusion = nullptr) {
    const size_t EB = 1000;
    Matrix<T> X;
    std::vector<uint8_t> y;
    size_t correct = 0;
    double loss = 0;
    for (size_t s = 0; s < idx.size(); s += EB) {
        const size_t n = std::min(EB, idx.size() - s);
        ds.fill_batch(idx.data() + s, n, X, y);
        const Matrix<T>& P = net.forward(X);
        loss += double(net.loss(y)) * double(n);
        for (size_t i = 0; i < n; ++i) {
            const T* p = P.row(i);
            const size_t pred = size_t(std::max_element(p, p + P.cols()) - p);
            correct += pred == y[i];
            if (confusion) (*confusion)[y[i]][pred]++;
        }
    }
    return {double(correct) / double(idx.size()), loss / double(idx.size())};
}

template <class T>
static int run(const Options& o) {
    Dataset tr = load_mnist(o.data + "/train-images-idx3-ubyte", o.data + "/train-labels-idx1-ubyte");
    Dataset te = load_mnist(o.data + "/t10k-images-idx3-ubyte", o.data + "/t10k-labels-idx1-ubyte");
    if (o.preload) { tr.preload_float(); te.preload_float(); }

    // Fixed split so every configuration sees the same validation images.
    std::vector<size_t> order(tr.n);
    std::iota(order.begin(), order.end(), 0);
    {
        std::mt19937_64 split_rng(2024);
        std::shuffle(order.begin(), order.end(), split_rng);
    }
    const size_t nval = std::min(o.val, tr.n / 2);
    std::vector<size_t> val_idx(order.begin(), order.begin() + nval);
    std::vector<size_t> train_idx(order.begin() + nval, order.end());
    std::vector<size_t> test_idx(te.n);
    std::iota(test_idx.begin(), test_idx.end(), 0);

    std::vector<size_t> sizes = {tr.dim};
    sizes.insert(sizes.end(), o.hidden.begin(), o.hidden.end());
    sizes.push_back(10);
    g_kernel = o.kernel;
    MLP<T> net(sizes, o.act, o.seed);

    int threads = 1;
#ifdef _OPENMP
    threads = omp_get_max_threads();
#endif
    if (!o.quiet) {
        std::printf("MLP");
        for (size_t s : sizes) std::printf(" %zu", s);
        std::printf(" | %zu params | %s | batch %zu lr %g mu %g | kernel=%s | %s | %d thread(s)\n", net.param_count(),
                    o.act == Act::ReLU ? "ReLU" : o.act == Act::Sigmoid ? "sigmoid" : "tanh", o.batch, o.lr, o.mu,
                    kernel_name(o.kernel), sizeof(T) == 4 ? "float32" : "float64", threads);
        std::printf("train %zu | validation %zu | test %zu (held out until the end)\n", train_idx.size(), nval, te.n);
    }

    std::mt19937_64 rng(o.seed + 1);
    Matrix<T> X;
    std::vector<uint8_t> y;
    double train_secs = 0, lr = o.lr;
    double rss_before = current_rss_mib();
    for (int e = 1; e <= o.epochs; ++e) {
        std::shuffle(train_idx.begin(), train_idx.end(), rng);
        Timer t;
        double loss_sum = 0;
        size_t nb = 0;
        for (size_t s = 0; s + o.batch <= train_idx.size(); s += o.batch, ++nb) {
            tr.fill_batch(train_idx.data() + s, o.batch, X, y);
            net.forward(X);
            loss_sum += double(net.loss(y));
            net.backward(X, y);
            net.step(T(lr), T(o.mu));
        }
        const double es = t.sec();
        train_secs += es;
        const EvalResult v = evaluate(net, tr, val_idx);
        if (!o.quiet)
            std::printf("epoch %2d | train loss %.4f | val loss %.4f  val acc %.2f%% | %.2fs (%.0f img/s)\n", e,
                        loss_sum / double(nb), v.loss, 100 * v.acc, es, double(nb * o.batch) / es);
        lr *= o.lr_decay;
    }

    // ---- final, single look at the unseen test set ----
    std::vector<std::vector<int>> conf(10, std::vector<int>(10, 0));
    Timer ti;
    const EvalResult tst = evaluate(net, te, test_idx, &conf);
    const double infer_secs = ti.sec();
    const EvalResult trn = evaluate(net, tr, train_idx);

    const double peak = peak_rss_mib();
    const double imgs = double(train_idx.size()) * o.epochs;
    if (o.csv) {
        // machine-readable: kernel,type,threads,hidden,train_s,img_per_s,test_acc,peak_rss_mib
        std::printf("CSV,%s,%s,%d,%zu,%.3f,%.0f,%.4f,%.1f\n", kernel_name(o.kernel), sizeof(T) == 4 ? "f32" : "f64", threads,
                    o.hidden[0], train_secs, imgs / train_secs, tst.acc, peak);
        return 0;
    }
    std::printf("\n== result ==\n");
    std::printf("TEST accuracy (unseen): %.2f%%   (%zu / %zu correct)   train acc %.2f%%\n", 100 * tst.acc,
                size_t(tst.acc * te.n + 0.5), te.n, 100 * trn.acc);
    std::printf("training: %.2fs total, %.0f images/s | inference on 10k test images: %.1f ms (%.0f img/s)\n", train_secs,
                imgs / train_secs, 1e3 * infer_secs, double(te.n) / infer_secs);
    const auto& p = net.profile;
    std::printf("time by phase (incl. validation passes): fwd gemm %.2fs, fwd elementwise %.2fs, bwd gemm %.2fs, bwd elementwise %.2fs, update %.2fs\n",
                p.fwd_gemm, p.fwd_elem, p.bwd_gemm, p.bwd_elem, p.update);
    std::printf("memory: peak RSS %.1f MiB | params+grads+momentum %.2f MiB | batch workspaces %.2f MiB | dataset %.1f MiB%s | RSS before training %.1f MiB\n",
                peak, net.param_bytes() / 1048576.0, net.workspace_bytes() / 1048576.0,
                (tr.pixels.size() + te.pixels.size() + (tr.pixels_f.size() + te.pixels_f.size()) * 4) / 1048576.0,
                o.preload ? " (uint8 + float copy)" : " (uint8)", rss_before);

    std::printf("\nconfusion matrix on test set (rows = true digit, cols = predicted):\n      ");
    for (int j = 0; j < 10; ++j) std::printf("%5d", j);
    std::printf("   recall\n");
    for (int i = 0; i < 10; ++i) {
        std::printf("  %d | ", i);
        int row = 0;
        for (int j = 0; j < 10; ++j) { std::printf("%5d", conf[i][j]); row += conf[i][j]; }
        std::printf("   %.1f%%\n", 100.0 * conf[i][i] / row);
    }
    return 0;
}

int main(int argc, char** argv) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        auto next = [&]() -> std::string {
            if (i + 1 >= argc) { std::fprintf(stderr, "missing value for %s\n", a.c_str()); std::exit(2); }
            return argv[++i];
        };
        if (a == "--data") o.data = next();
        else if (a == "--hidden") o.hidden = parse_list(next());
        else if (a == "--act") {
            const std::string s = next();
            o.act = s == "relu" ? Act::ReLU : s == "sigmoid" ? Act::Sigmoid : Act::Tanh;
        } else if (a == "--epochs") o.epochs = std::stoi(next());
        else if (a == "--lr") o.lr = std::stod(next());
        else if (a == "--mu") o.mu = std::stod(next());
        else if (a == "--lr-decay") o.lr_decay = std::stod(next());
        else if (a == "--batch") o.batch = std::stoul(next());
        else if (a == "--val") o.val = std::stoul(next());
        else if (a == "--seed") o.seed = std::stoull(next());
        else if (a == "--double") o.use_double = true;
        else if (a == "--preload") o.preload = true;
        else if (a == "--quiet") o.quiet = true;
        else if (a == "--csv") { o.csv = true; o.quiet = true; }
        else if (a == "--kernel") {
            if (!parse_kernel(next().c_str(), o.kernel)) { std::fprintf(stderr, "kernel: naive|reordered|blocked|tiled\n"); return 2; }
        } else { std::fprintf(stderr, "unknown flag %s\n", a.c_str()); return 2; }
    }
    try {
        return o.use_double ? run<double>(o) : run<float>(o);
    } catch (const std::exception& e) {
        std::fprintf(stderr, "error: %s\n", e.what());
        return 1;
    }
}
