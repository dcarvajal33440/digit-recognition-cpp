// activations.hpp - activation functions, their derivatives, softmax.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>

#include "tensor.hpp"

namespace nn {

enum class Act { ReLU, Sigmoid, Tanh };

// Numerically stable logistic function: never evaluates exp() of a large positive number.
template <class T>
inline T sigmoid(T x) {
    if (x >= T(0)) return T(1) / (T(1) + std::exp(-x));
    const T e = std::exp(x);
    return e / (T(1) + e);
}

// Z -> A = f(Z), elementwise
template <class T>
void activate(Act a, const Matrix<T>& Z, Matrix<T>& A) {
    A.resize(Z.rows(), Z.cols());
    const size_t n = Z.size();
    const T* z = Z.data();
    T* o = A.data();
    switch (a) {
        case Act::ReLU:
#pragma omp simd
            for (size_t i = 0; i < n; ++i) o[i] = z[i] > T(0) ? z[i] : T(0);
            break;
        case Act::Sigmoid:
            for (size_t i = 0; i < n; ++i) o[i] = sigmoid(z[i]);
            break;
        case Act::Tanh:
            for (size_t i = 0; i < n; ++i) o[i] = std::tanh(z[i]);
            break;
    }
}

// dZ = dA * f'(Z), written with the already-computed A = f(Z) where that is cheaper.
template <class T>
void activation_backward(Act a, const Matrix<T>& Z, const Matrix<T>& A, const Matrix<T>& dA, Matrix<T>& dZ) {
    dZ.resize(Z.rows(), Z.cols());
    const size_t n = Z.size();
    const T *z = Z.data(), *act = A.data(), *da = dA.data();
    T* o = dZ.data();
    switch (a) {
        case Act::ReLU:
#pragma omp simd
            for (size_t i = 0; i < n; ++i) o[i] = z[i] > T(0) ? da[i] : T(0);
            break;
        case Act::Sigmoid:  // s' = s (1 - s)
#pragma omp simd
            for (size_t i = 0; i < n; ++i) o[i] = da[i] * act[i] * (T(1) - act[i]);
            break;
        case Act::Tanh:  // t' = 1 - t^2
#pragma omp simd
            for (size_t i = 0; i < n; ++i) o[i] = da[i] * (T(1) - act[i] * act[i]);
            break;
    }
}

// Row-wise softmax with the max subtracted first (shift invariance) so exp() cannot overflow.
template <class T>
void softmax_rows(const Matrix<T>& Z, Matrix<T>& P) {
    P.resize(Z.rows(), Z.cols());
    const size_t R = Z.rows(), C = Z.cols();
    for (size_t i = 0; i < R; ++i) {
        const T* z = Z.row(i);
        T* p = P.row(i);
        T mx = z[0];
        for (size_t j = 1; j < C; ++j) mx = std::max(mx, z[j]);
        T sum = 0;
        for (size_t j = 0; j < C; ++j) {
            p[j] = std::exp(z[j] - mx);
            sum += p[j];
        }
        const T inv = T(1) / sum;
        for (size_t j = 0; j < C; ++j) p[j] *= inv;
    }
}

}  // namespace nn
