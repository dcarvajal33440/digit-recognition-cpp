// mlp.hpp - a fully-connected network with softmax cross-entropy, trained by
// mini-batch gradient descent. Everything (forward, backprop, update) is written
// out explicitly on top of gemm.hpp; no ML framework is involved.
//
// Notation, for a batch of B examples and layer l with n_in -> n_out units:
//     forward :  Z_l = A_{l-1} W_l + b_l          A_l = f(Z_l)       (last layer: A = softmax(Z))
//     loss    :  L = -(1/B) sum_i log A_L[i, y_i]
//     backward:  dZ_L     = (A_L - onehot(y)) / B                   (softmax + cross-entropy collapse)
//                dW_l     = A_{l-1}^T dZ_l       db_l = column sums of dZ_l
//                dA_{l-1} = dZ_l W_l^T           dZ_{l-1} = dA_{l-1} * f'(Z_{l-1})
//     update  :  W <- W - lr * dW     (optionally with momentum)
#pragma once

#include <cmath>
#include <cstdint>
#include <random>
#include <vector>

#include "activations.hpp"
#include "gemm.hpp"
#include "util.hpp"

namespace nn {

template <class T>
class MLP {
public:
    struct Layer {
        Matrix<T> W, b;    // W: n_in x n_out, b: 1 x n_out
        Matrix<T> dW, db;  // gradients
        Matrix<T> vW, vb;  // momentum buffers (allocated lazily)
    };
    struct Profile {  // seconds spent per phase
        double fwd_gemm = 0, fwd_elem = 0, bwd_gemm = 0, bwd_elem = 0, update = 0;
        double total() const { return fwd_gemm + fwd_elem + bwd_gemm + bwd_elem + update; }
    };

    MLP(const std::vector<size_t>& sizes, Act hidden, uint64_t seed) : sizes_(sizes), hidden_(hidden) {
        const size_t L = sizes.size() - 1;
        layers_.resize(L);
        std::mt19937_64 rng(seed);
        for (size_t l = 0; l < L; ++l) {
            Layer& ly = layers_[l];
            const size_t in = sizes[l], out = sizes[l + 1];
            ly.W.resize(in, out);
            ly.b.resize(1, out);
            ly.dW.resize(in, out);
            ly.db.resize(1, out);
            // He init for ReLU hidden layers, Xavier otherwise (and for the softmax layer).
            const bool he = (hidden_ == Act::ReLU) && (l + 1 < L);
            const double sd = he ? std::sqrt(2.0 / double(in)) : std::sqrt(2.0 / double(in + out));
            std::normal_distribution<double> N(0.0, sd);
            for (size_t i = 0; i < ly.W.size(); ++i) ly.W.data()[i] = T(N(rng));
        }
        Z_.resize(L); A_.resize(L); dZ_.resize(L); dIn_.resize(L);
    }

    size_t num_layers() const { return layers_.size(); }
    std::vector<Layer>& layers() { return layers_; }
    Profile profile;

    // Forward pass; returns class probabilities (B x n_classes).
    const Matrix<T>& forward(const Matrix<T>& X) {
        const size_t L = layers_.size();
        for (size_t l = 0; l < L; ++l) {
            const Matrix<T>& in = (l == 0) ? X : A_[l - 1];
            Timer t;
            gemm_nn(in, layers_[l].W, Z_[l]);
            profile.fwd_gemm += t.sec();
            t.reset();
            add_bias(Z_[l], layers_[l].b);
            if (l + 1 < L) activate(hidden_, Z_[l], A_[l]);
            else softmax_rows(Z_[l], A_[l]);
            profile.fwd_elem += t.sec();
        }
        return A_[L - 1];
    }

    // Mean cross-entropy of the last forward() against labels.
    T loss(const std::vector<uint8_t>& y) const {
        const Matrix<T>& P = A_.back();
        double s = 0;
        for (size_t i = 0; i < P.rows(); ++i) s -= std::log(std::max<double>(P(i, y[i]), 1e-300));
        return T(s / double(P.rows()));
    }

    // Backprop. Requires forward(X) to have just been called on the same X.
    void backward(const Matrix<T>& X, const std::vector<uint8_t>& y) {
        const size_t L = layers_.size();
        const size_t B = X.rows();
        Timer t;
        {  // dZ_L = (P - onehot) / B
            Matrix<T>& dZ = dZ_[L - 1];
            dZ = A_[L - 1];  // copies probabilities
            const T inv = T(1) / T(B);
            for (size_t i = 0; i < B; ++i) dZ(i, y[i]) -= T(1);
            for (size_t i = 0; i < dZ.size(); ++i) dZ.data()[i] *= inv;
        }
        profile.bwd_elem += t.sec();
        for (size_t l = L; l-- > 0;) {
            Layer& ly = layers_[l];
            const Matrix<T>& in = (l == 0) ? X : A_[l - 1];
            t.reset();
            gemm_tn(in, dZ_[l], ly.dW);  // dW = in^T dZ
            profile.bwd_gemm += t.sec();
            t.reset();
            column_sums(dZ_[l], ly.db);
            profile.bwd_elem += t.sec();
            if (l > 0) {
                t.reset();
                gemm_nt(dZ_[l], ly.W, dIn_[l]);  // dIn = dZ W^T
                profile.bwd_gemm += t.sec();
                t.reset();
                activation_backward(hidden_, Z_[l - 1], A_[l - 1], dIn_[l], dZ_[l - 1]);
                profile.bwd_elem += t.sec();
            }
        }
    }

    // Gradient-descent update: plain, or with classical momentum when mu > 0.
    void step(T lr, T mu = 0) {
        Timer t;
        for (Layer& ly : layers_) {
            sgd(ly.W, ly.dW, ly.vW, lr, mu);
            sgd(ly.b, ly.db, ly.vb, lr, mu);
        }
        profile.update += t.sec();
    }

    // Bytes held by parameters + gradients (+ momentum) and by the batch workspaces.
    size_t param_bytes() const {
        size_t s = 0;
        for (const Layer& l : layers_) s += l.W.bytes() + l.b.bytes() + l.dW.bytes() + l.db.bytes() + l.vW.bytes() + l.vb.bytes();
        return s;
    }
    size_t workspace_bytes() const {
        size_t s = 0;
        for (size_t l = 0; l < layers_.size(); ++l) s += Z_[l].bytes() + A_[l].bytes() + dZ_[l].bytes() + dIn_[l].bytes();
        return s;
    }
    size_t param_count() const {
        size_t s = 0;
        for (const Layer& l : layers_) s += l.W.size() + l.b.size();
        return s;
    }

private:
    static void add_bias(Matrix<T>& Z, const Matrix<T>& b) {
        const size_t R = Z.rows(), C = Z.cols();
        const T* bp = b.data();
        for (size_t i = 0; i < R; ++i) {
            T* z = Z.row(i);
#pragma omp simd
            for (size_t j = 0; j < C; ++j) z[j] += bp[j];
        }
    }
    static void column_sums(const Matrix<T>& M, Matrix<T>& out) {
        out.resize(1, M.cols());
        out.zero();
        T* o = out.data();
        for (size_t i = 0; i < M.rows(); ++i) {
            const T* r = M.row(i);
#pragma omp simd
            for (size_t j = 0; j < M.cols(); ++j) o[j] += r[j];
        }
    }
    static void sgd(Matrix<T>& P, const Matrix<T>& G, Matrix<T>& V, T lr, T mu) {
        T* p = P.data();
        const T* g = G.data();
        const long n = long(P.size());
        // Measured on 784-128-10 (100k params): threading this loop made training slower (2 cores
        // ping-pong the optimiser state between their private L2s), so only parallelise big layers.
        [[maybe_unused]] const bool par = n >= (1L << 18);
        if (mu == T(0)) {
#pragma omp parallel for simd schedule(static) if (par)
            for (long i = 0; i < n; ++i) p[i] -= lr * g[i];
        } else {
            V.resize(P.rows(), P.cols());
            T* v = V.data();
#pragma omp parallel for simd schedule(static) if (par)
            for (long i = 0; i < n; ++i) {
                v[i] = mu * v[i] - lr * g[i];
                p[i] += v[i];
            }
        }
    }

    std::vector<size_t> sizes_;
    Act hidden_;
    std::vector<Layer> layers_;
    std::vector<Matrix<T>> Z_, A_, dZ_, dIn_;  // per-layer batch workspaces
};

}  // namespace nn
