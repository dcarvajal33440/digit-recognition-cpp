// mnist.hpp - IDX file loader and batch assembly.
//
// Pixels are kept as raw uint8 (1 byte/pixel = 55 MB for all of MNIST) and
// converted to float [0,1] one mini-batch at a time. An optional "preload"
// mode keeps a float copy instead (4x the memory) - used as the memory baseline.
#pragma once

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>

#include "tensor.hpp"

namespace nn {

struct Dataset {
    size_t n = 0, dim = 0;
    std::vector<uint8_t> pixels;  // n * dim
    std::vector<uint8_t> labels;  // n
    std::vector<float> pixels_f;  // optional float copy (preload mode)

    void preload_float() {
        pixels_f.resize(pixels.size());
        for (size_t i = 0; i < pixels.size(); ++i) pixels_f[i] = pixels[i] * (1.0f / 255.0f);
    }

    // Copy rows idx[0..count) into X (count x dim) as floats in [0,1], labels into y.
    template <class T>
    void fill_batch(const size_t* idx, size_t count, Matrix<T>& X, std::vector<uint8_t>& y) const {
        X.resize(count, dim);
        y.resize(count);
        for (size_t b = 0; b < count; ++b) {
            const size_t r = idx[b];
            T* dst = X.row(b);
            if (!pixels_f.empty()) {
                const float* src = pixels_f.data() + r * dim;
                for (size_t j = 0; j < dim; ++j) dst[j] = T(src[j]);
            } else {
                const uint8_t* src = pixels.data() + r * dim;
                for (size_t j = 0; j < dim; ++j) dst[j] = T(src[j]) * T(1.0 / 255.0);
            }
            y[b] = labels[r];
        }
    }
};

namespace detail {
struct File {  // RAII FILE*
    FILE* f;
    explicit File(const std::string& path) : f(std::fopen(path.c_str(), "rb")) {
        if (!f) throw std::runtime_error("cannot open " + path);
    }
    ~File() { std::fclose(f); }
    File(const File&) = delete;
    File& operator=(const File&) = delete;
    void read(void* dst, size_t n, const std::string& what) {
        if (std::fread(dst, 1, n, f) != n) throw std::runtime_error("short read on " + what);
    }
    bool at_eof() { return std::fgetc(f) == EOF; }
};
inline uint32_t be32(const uint8_t* p) {
    return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) | (uint32_t(p[2]) << 8) | uint32_t(p[3]);
}
}  // namespace detail

// The payload is read straight into its final buffer. (An earlier version slurped the whole
// file into a temporary and copied it, which doubled peak memory: 93 MiB instead of ~55.)
inline Dataset load_mnist(const std::string& images_path, const std::string& labels_path) {
    Dataset d;
    {
        detail::File f(images_path);
        uint8_t h[16];
        f.read(h, sizeof h, images_path);
        if (detail::be32(h) != 2051) throw std::runtime_error("bad image magic: " + images_path);
        const size_t n = detail::be32(h + 4), rows = detail::be32(h + 8), cols = detail::be32(h + 12);
        d.n = n;
        d.dim = rows * cols;
        d.pixels.resize(n * d.dim);
        f.read(d.pixels.data(), d.pixels.size(), images_path);
        if (!f.at_eof()) throw std::runtime_error("image file size mismatch");
    }
    {
        detail::File f(labels_path);
        uint8_t h[8];
        f.read(h, sizeof h, labels_path);
        if (detail::be32(h) != 2049) throw std::runtime_error("bad label magic: " + labels_path);
        const size_t n = detail::be32(h + 4);
        if (n != d.n) throw std::runtime_error("label file mismatch");
        d.labels.resize(n);
        f.read(d.labels.data(), n, labels_path);
        if (!f.at_eof()) throw std::runtime_error("label file size mismatch");
    }
    return d;
}

}  // namespace nn
