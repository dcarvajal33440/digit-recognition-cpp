// tensor.hpp - a minimal dense row-major matrix, written from scratch.
//
// Storage is 64-byte aligned (one cache line, and the width of an AVX-512
// register) so the vectorised kernels can use aligned, full-line accesses.
#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <new>
#include <utility>

namespace nn {

template <class T>
class Matrix {
public:
    Matrix() = default;
    Matrix(size_t r, size_t c) { resize(r, c); }
    Matrix(const Matrix& o) {
        resize(o.r_, o.c_);
        if (o.d_) std::memcpy(d_, o.d_, bytes());
    }
    Matrix(Matrix&& o) noexcept { swap(o); }
    Matrix& operator=(Matrix o) noexcept { swap(o); return *this; }
    ~Matrix() { std::free(d_); }

    // Re-shape. A no-op when the shape is unchanged (so per-batch workspaces
    // are allocated once and then reused). New contents are zeroed.
    void resize(size_t r, size_t c) {
        if (d_ && r == r_ && c == c_) return;
        std::free(d_);
        d_ = nullptr;
        r_ = r;
        c_ = c;
        size_t b = (bytes() + 63) / 64 * 64;  // aligned_alloc wants a multiple of the alignment
        if (b == 0) b = 64;
        d_ = static_cast<T*>(std::aligned_alloc(64, b));
        if (!d_) throw std::bad_alloc();
        zero();
    }

    void zero() { if (d_) std::memset(d_, 0, bytes()); }

    size_t rows() const { return r_; }
    size_t cols() const { return c_; }
    size_t size() const { return r_ * c_; }
    size_t bytes() const { return r_ * c_ * sizeof(T); }

    T* data() { return d_; }
    const T* data() const { return d_; }
    T* row(size_t i) { return d_ + i * c_; }
    const T* row(size_t i) const { return d_ + i * c_; }
    T& operator()(size_t i, size_t j) { return d_[i * c_ + j]; }
    const T& operator()(size_t i, size_t j) const { return d_[i * c_ + j]; }

    void swap(Matrix& o) noexcept {
        std::swap(r_, o.r_);
        std::swap(c_, o.c_);
        std::swap(d_, o.d_);
    }

private:
    size_t r_ = 0, c_ = 0;
    T* d_ = nullptr;
};

// out = m^T
template <class T>
void transpose(const Matrix<T>& m, Matrix<T>& out) {
    out.resize(m.cols(), m.rows());
    const size_t R = m.rows(), C = m.cols();
    constexpr size_t BS = 32;  // tile so both the reads and the writes stay cache-friendly
    for (size_t i0 = 0; i0 < R; i0 += BS)
        for (size_t j0 = 0; j0 < C; j0 += BS) {
            const size_t i1 = std::min(i0 + BS, R), j1 = std::min(j0 + BS, C);
            for (size_t i = i0; i < i1; ++i)
                for (size_t j = j0; j < j1; ++j) out(j, i) = m(i, j);
        }
}

}  // namespace nn
