// bench_gemm.cpp - GFLOP/s of every GEMM kernel on the shapes the MNIST MLP actually
// produces (batch 64 and 256, 784-128-10), plus one big square product for reference.
//   OMP_NUM_THREADS=1 ./bench_gemm     # single-thread numbers
#include <cstdio>
#include <random>
#include <string>
#include <vector>

#include "gemm.hpp"
#include "util.hpp"

using namespace nn;

struct Case { const char* name; int variant; size_t M, N, K; };

static double bench(const Case& c, Kernel k) {
    Matrix<float> A(c.variant == 1 ? c.K : c.M, c.variant == 1 ? c.M : c.K);
    Matrix<float> B(c.variant == 2 ? c.N : c.K, c.variant == 2 ? c.K : c.N);
    Matrix<float> C;
    std::mt19937 rng(1);
    std::uniform_real_distribution<float> U(-1, 1);
    for (size_t i = 0; i < A.size(); ++i) A.data()[i] = U(rng);
    for (size_t i = 0; i < B.size(); ++i) B.data()[i] = U(rng);
    g_kernel = k;
    auto once = [&]() {
        if (c.variant == 0) gemm_nn(A, B, C);
        else if (c.variant == 1) gemm_tn(A, B, C);
        else gemm_nt(A, B, C);
    };
    once();  // warm-up (allocations, page faults, thread pool)
    const double flops = 2.0 * c.M * c.N * c.K;
    // Run for ~0.25 s, keep the best of several timed chunks: robust to noisy neighbours.
    double best = 1e30;
    Timer total;
    while (total.sec() < 0.25) {
        int reps = 1;
        Timer t;
        once();
        double dt = t.sec();
        if (dt < 2e-3) {  // too short to time reliably: batch repetitions
            reps = int(2e-3 / dt) + 1;
            t.reset();
            for (int r = 0; r < reps; ++r) once();
            dt = t.sec();
        }
        best = std::min(best, dt / reps);
    }
    return flops / best / 1e9;
}

int main() {
    const Case cases[] = {
        {"fwd  L1 B=64   (64x784)*(784x128)", 0, 64, 128, 784},
        {"fwd  L2 B=64   (64x128)*(128x10)", 0, 64, 10, 128},
        {"dW   L1 B=64   (784x64)*(64x128)", 1, 784, 128, 64},
        {"dIn  L2 B=64   (64x10)*(10x128)", 2, 64, 128, 10},
        {"fwd  L1 B=256", 0, 256, 128, 784},
        {"dW   L1 B=256", 1, 784, 128, 256},
        {"square 512^3", 0, 512, 512, 512},
    };
    const Kernel kernels[] = {Kernel::Naive, Kernel::Reordered, Kernel::Blocked, Kernel::Tiled};
    std::printf("%-40s", "GFLOP/s (float32)");
    for (Kernel k : kernels) std::printf("%11s", kernel_name(k));
    std::printf("\n");
    for (const Case& c : cases) {
        std::printf("%-40s", c.name);
        for (Kernel k : kernels) std::printf("%11.2f", bench(c, k));
        std::printf("\n");
    }
    return 0;
}
